module.exports = {
  transpileDependencies: ['vue-spinner']
}
